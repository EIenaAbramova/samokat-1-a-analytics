"""Read original Excel without modifying it; independently calculate control results."""
from pathlib import Path
from collections import defaultdict, Counter
from datetime import datetime, timedelta
from zipfile import ZipFile
from lxml import etree as E
from openpyxl import load_workbook
import json

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT.parent / 'Тестирование_корпоративная_аналитика.xlsx'
if not SOURCE.exists(): SOURCE=ROOT/'input/Тестирование_корпоративная_аналитика.xlsx'
for folder in ['qa','output','docs']:(ROOT/folder).mkdir(exist_ok=True)
w = load_workbook(SOURCE, data_only=True)
a, b = [list(s.values)[1:] for s in w.worksheets[1:]]
assert len(a) == len(b) == 504
assert len({r[:2] for r in a}) == len(a)
assert len({r[:2] for r in b}) == len(b)
lookup = {r[:2]: r[2:] for r in b}
assert set(lookup) == {r[:2] for r in a}
epoch = datetime(1899,12,30)
rows = []
for r in sorted(a, key=lambda r:r[:2]):
 d,t = r[:2]
 start = d - timedelta(days=d.weekday())
 rows.append([(d-epoch).days,t,*r[2:6],*lookup[(d,t)],(start-epoch).days,d.isocalendar().year,d.isocalendar().week])
groups = defaultdict(list)
for r in rows: groups[(r[9],r[1])].append(r)
weeks = sorted({r[9] for r in rows})
latest = max(r[0] for r in rows)
last_full = latest - ((epoch+timedelta(days=latest)).weekday()) - 7
def aggregate(rs,days_override=None):
 sales,cost,loss,wdays,orders,clients = [sum(r[i] for r in rs) for i in (3,4,5,6,7,8)]
 days=days_override or len({r[0] for r in rs})
 return dict(sales=sales,cost=cost,loss=loss,warehouse_days=wdays,observed_days=days,avg_warehouses=wdays/days,per_warehouse=sales/(wdays/days),markup=(sales-cost)/cost,yield_rate=(sales-cost-loss)/sales,orders=orders,client_days=clients)
weekly = [{'week':x,**aggregate([r for r in rows if r[9]==x])} for x in weeks]
last = [{'territory':t,**aggregate(rs,7)} for (x,t),rs in groups.items() if x==last_full]
total = sum(x['sales'] for x in last)
for x in last: x['share']=x['sales']/total
charts=[]
ns={'c':'http://schemas.openxmlformats.org/drawingml/2006/chart','a':'http://schemas.openxmlformats.org/drawingml/2006/main'}
with ZipFile(SOURCE) as z:
 for i in range(1,9):
  tree=E.fromstring(z.read(f'xl/charts/chart{i}.xml'))
  s=tree.xpath('//c:ser',namespaces=ns)[-1]
  charts.append({'title':''.join(tree.xpath('//c:title//a:t/text()',namespaces=ns)), 'series':s.xpath('./c:tx//c:v/text()',namespaces=ns)[0], 'months':s.xpath('./c:cat//c:pt/c:v/text()',namespaces=ns),'values':[float(x) for x in s.xpath('./c:val//c:pt/c:v/text()',namespaces=ns)]})
payload={'rows':rows,'territories':sorted({r[1] for r in rows}),'weeks':weeks,'last_full':last_full,'charts':charts,'source_headers':[list(s.values)[0] for s in w.worksheets[1:]],'source1':[[r[0].isoformat(),*r[1:6]] for r in a],'source2':[[r[0].isoformat(),*r[1:]] for r in b]}
(ROOT/'qa/data.json').write_text(json.dumps(payload,ensure_ascii=False),encoding='utf-8')
results={'rows':len(rows),'dates':len({r[0] for r in rows}),'territories':len(payload['territories']),'matched':len(rows),'unmatched':0,'last_full_week':(epoch+timedelta(days=last_full)).date().isoformat(),'weekly':weekly,'top_share':sorted(last,key=lambda x:(-x['share'],x['territory']))[:3],'top_per_warehouse':sorted(last,key=lambda x:(-x['per_warehouse'],x['territory']))[:3],'last_week':last,'missing_territory_days':len(payload['territories'])*len({r[0] for r in rows})-len(rows)}
(ROOT/'output/summary.json').write_text(json.dumps(results,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({k:results[k] for k in ['rows','dates','territories','last_full_week','top_share','top_per_warehouse']},ensure_ascii=False,indent=2))
