"""Supplement native PivotTable OOXML because artifact-tool pivot XLSX export is unreliable.
Uses lxml/zipfile only; source workbook is authored by build.mjs.
"""
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
from collections import defaultdict
from lxml import etree as E
import json

ROOT=Path(__file__).resolve().parents[1]
FILE=ROOT/'output/Самокат_1_A_решение.xlsx'
rows=json.loads((ROOT/'qa/data.json').read_text(encoding='utf-8'))['rows']
rows=[[*r,f'{r[0]}|{r[1]}',1] for r in rows]
NS='http://schemas.openxmlformats.org/spreadsheetml/2006/main'
REL='http://schemas.openxmlformats.org/package/2006/relationships'
R='http://schemas.openxmlformats.org/officeDocument/2006/relationships'
CT='http://schemas.openxmlformats.org/package/2006/content-types'
def el(tag,parent=None,**attrs):
 x=E.Element('{'+NS+'}'+tag,**{k:str(v) for k,v in attrs.items()})
 if parent is not None: parent.append(x)
 return x
def xml(x):return E.tostring(x,xml_declaration=True,encoding='UTF-8',standalone=True)
with ZipFile(FILE) as z: files={n:z.read(n) for n in z.namelist()}
headers=['Дата','Территория','Товарооборот шт','Товарооборот руб','Себестоимость руб','Потери руб','Склады за день','Заказы за день','Клиенты за день','Понедельник ISO','Год ISO','Неделя ISO','Ключ','Совпадений ключа']
uniques=[sorted({r[c] for r in rows}) for c in range(14)]
maps=[{v:i for i,v in enumerate(u)} for u in uniques]
cache=el('pivotCacheDefinition',saveData='1',refreshOnLoad='0',recordCount=len(rows),createdVersion=6,refreshedVersion=6,minRefreshableVersion=3)
cache.set('{'+R+'}id','rId1')
cs=el('cacheSource',cache,type='worksheet');el('worksheetSource',cs,ref='A1:N505',sheet='Данные')
fields=el('cacheFields',cache,count=14)
for c in range(14):
 field=el('cacheField',fields,name=headers[c],numFmtId=14 if c in (0,9) else 0)
 istext=isinstance(uniques[c][0],str)
 shared=el('sharedItems',field,count=len(uniques[c]),containsString='1' if istext else '0',containsNumber='0' if istext else '1',containsSemiMixedTypes='0')
 for v in uniques[c]:el('s' if istext else 'n',shared,v=v)
records=el('pivotCacheRecords',count=len(rows))
for row in rows:
 rec=el('r',records)
 for c,v in enumerate(row):el('x',rec,v=maps[c][v])
gr=defaultdict(lambda:[0.0]*6)
for r in rows:
 for j in range(6):gr[(r[9],r[1])][j]+=r[3+j]
keys=sorted(gr)
piv=el('pivotTableDefinition',name='WeeklyTerritories',cacheId=1,dataCaption='Показатели',rowGrandTotals='1',colGrandTotals='0',compact='0',compactData='0',gridDropZones='1',multipleFieldFilters='0',updatedVersion=6,minRefreshableVersion=3,createdVersion=6)
el('location',piv,ref=f'A5:H{6+len(keys)}',firstHeaderRow=0,firstDataRow=1,firstDataCol=2)
pfields=el('pivotFields',piv,count=14)
for c in range(14):
 pf=el('pivotField',pfields,**({'axis':'axisRow','showAll':'0','defaultSubtotal':'0','compact':'0','outline':'0','numFmtId':14 if c==9 else 0} if c in (1,9) else {'dataField':'1'} if c in range(3,9) else {'showAll':'0'}))
 if c in (1,9):
  items=el('items',pf,count=len(uniques[c]))
  for idx in range(len(uniques[c])):el('item',items,x=idx)
rf=el('rowFields',piv,count=2);el('field',rf,x=9);el('field',rf,x=1)
ri=el('rowItems',piv,count=len(keys)+1)
for week,t in keys:
 item=el('i',ri);el('x',item,v=maps[9][week]);el('x',item,v=maps[1][t])
item=el('i',ri,t='grand');el('x',item)
cf=el('colFields',piv,count=1);el('field',cf,x=-2)
ci=el('colItems',piv,count=6)
for i in range(6):item=el('i',ci,i=i);el('x',item)
df=el('dataFields',piv,count=6)
labels=['Оборот руб','Себестоимость руб','Потери руб','Складо дни','Заказы','Клиенто дни']
for i,label in enumerate(labels):el('dataField',df,name=label,fld=3+i,subtotal='sum',baseField=0,baseItem=0,numFmtId=4)
el('pivotTableStyleInfo',piv,name='PivotStyleLight16',showRowHeaders='1',showColHeaders='1',showRowStripes='1',showColStripes='0',showLastColumn='1')
sheet=E.fromstring(files['xl/worksheets/sheet9.xml'])
sd=sheet.find('{'+NS+'}sheetData')
for row in list(sd):
 if int(row.get('r'))>=5:sd.remove(row)
styles_from=E.fromstring(files['xl/worksheets/sheet2.xml'])
def style_at(addr):return styles_from.find('.//{'+NS+'}c[@r="'+addr+'"]').get('s','0')
header_style=style_at('B5');text_style=style_at('B5');number_style=style_at('D5');date_style=style_at('A5')
def write_row(num,values):
 row=el('row',sd,r=num,ht=32 if num==5 else 21,customHeight='1')
 for i,v in enumerate(values):
  cell=el('c',row,r=f'{chr(65+i)}{num}',s=header_style if num==5 else date_style if i==0 and isinstance(v,(float,int)) else text_style if isinstance(v,str) else number_style)
  if isinstance(v,str):cell.set('t','inlineStr');el('t',el('is',cell)).text=v
  else:el('v',cell).text=str(v)
write_row(5,['Понедельник ISO','Территория',*labels])
from datetime import datetime,timedelta
for i,key in enumerate(keys):write_row(i+6,[key[0],key[1],*gr[key]])
write_row(len(keys)+6,['Общий итог','',*[sum(v[j] for v in gr.values()) for j in range(6)]])
parts=el('pivotParts',sheet,count=1);part=el('pivotPart',parts);part.set('{'+R+'}id','rIdPivot')
dim=sheet.find('{'+NS+'}dimension')
if dim is not None:dim.set('ref',f'A1:J{len(keys)+6}')
files['xl/worksheets/sheet9.xml']=xml(sheet)
wb=E.fromstring(files['xl/workbook.xml']);pc=el('pivotCaches');pcitem=el('pivotCache',pc,cacheId=1);pcitem.set('{'+R+'}id','rIdPivotCache')
ext=wb.find('{'+NS+'}extLst');wb.insert(list(wb).index(ext) if ext is not None else len(wb),pc)
files['xl/workbook.xml']=xml(wb)
def relationship_file(name,id,type,target):
 rel=E.fromstring(files[name]) if name in files else E.Element('{'+REL+'}Relationships',nsmap={None:REL})
 E.SubElement(rel,'{'+REL+'}Relationship',Id=id,Type=R+'/'+type,Target=target)
 files[name]=xml(rel)
relationship_file('xl/_rels/workbook.xml.rels','rIdPivotCache','pivotCacheDefinition','pivotCache/pivotCacheDefinition1.xml')
relationship_file('xl/worksheets/_rels/sheet9.xml.rels','rIdPivot','pivotTable','../pivotTables/pivotTable1.xml')
relationship_file('xl/pivotTables/_rels/pivotTable1.xml.rels','rId1','pivotCacheDefinition','../pivotCache/pivotCacheDefinition1.xml')
relationship_file('xl/pivotCache/_rels/pivotCacheDefinition1.xml.rels','rId1','pivotCacheRecords','pivotCacheRecords1.xml')
files['xl/pivotTables/pivotTable1.xml']=xml(piv)
files['xl/pivotCache/pivotCacheDefinition1.xml']=xml(cache)
files['xl/pivotCache/pivotCacheRecords1.xml']=xml(records)
cts=E.fromstring(files['[Content_Types].xml'])
for name,typ in [('pivotTables/pivotTable1.xml','pivotTable'),('pivotCache/pivotCacheDefinition1.xml','pivotCacheDefinition'),('pivotCache/pivotCacheRecords1.xml','pivotCacheRecords')]:
 E.SubElement(cts,'{'+CT+'}Override',PartName='/xl/'+name,ContentType='application/vnd.openxmlformats-officedocument.spreadsheetml.'+typ+'+xml')
files['[Content_Types].xml']=xml(cts)
with ZipFile(FILE,'w',ZIP_DEFLATED) as z:
 for n,b in files.items():z.writestr(n,b)
from openpyxl import load_workbook
check=load_workbook(FILE)
assert len(check['Сводная']._pivots)==1
assert len(check['Сводная']._pivots[0].cache.records.r)==504
print('Native PivotTable parsed; 504 cache records;',len(keys),'week/territory groups')
