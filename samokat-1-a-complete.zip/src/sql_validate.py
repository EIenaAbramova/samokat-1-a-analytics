"""Parse actual T-SQL and execute transpiled SELECTs against synthetic edge cases.
This is supplemental validation, not execution in Microsoft SQL Server.
"""
from pathlib import Path
import sys,re,json
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'qa/sql_lib'))
import duckdb,sqlglot
from sqlglot import exp

conn=duckdb.connect()
conn.execute('CREATE SCHEMA dbo')
conn.execute('CREATE TABLE dbo.warehouses(warehouse_id BIGINT,name VARCHAR,city VARCHAR,date_open DATE,date_close DATE)')
conn.execute('CREATE TABLE dbo.product(product_id BIGINT,name VARCHAR,group1 VARCHAR,group2 VARCHAR,group3 VARCHAR,weight DECIMAL(18,3),shelf_life INT)')
conn.execute('CREATE TABLE dbo.orders(order_id BIGINT,warehouse_id BIGINT,user_id BIGINT,date TIMESTAMP,paid_amount DECIMAL(18,4),quantity DECIMAL(18,3))')
conn.execute('CREATE TABLE dbo.order_line(order_id BIGINT,date TIMESTAMP,warehouse_id BIGINT,product_id BIGINT,price DECIMAL(18,4),regular_price DECIMAL(18,4),cost_price DECIMAL(18,4),quantity DECIMAL(18,3),paid_amount DECIMAL(18,4))')
conn.execute('CREATE TABLE dbo.lost(date TIMESTAMP,warehouse_id BIGINT,product_id BIGINT,item_id BIGINT,quantity DECIMAL(18,3),amount DECIMAL(18,4))')
conn.executemany('INSERT INTO dbo.warehouses VALUES (?,?,?,?,?)',[(1,'А','Москва','2019-01-01',None),(2,'Б','Москва','2019-01-01',None),(3,'В','Москва','2022-01-01',None),(4,'Г','Казань','2019-01-01',None),*[(100+i,f'Склад {i}','Тест','2019-01-01',None) for i in range(51)],(200,'Закрыт','Тест','2019-01-01','2021-06-01'),(201,'Будущий','Тест','2022-01-01',None)])
conn.executemany('INSERT INTO dbo.product VALUES (?,?,?,?,?,?,?)',[(i,('САМОКАТ' if i==1 else 'самокат' if i==2 else f'Товар {i}'),'G','A' if i<=12 else 'B','x',1,7 if i==1 else 8) for i in range(1,14)])
conn.executemany('INSERT INTO dbo.orders VALUES (?,?,?,?,?,?)',[(1,1,1,'2021-01-31 23:59:59',100,1),(2,4,1,'2021-01-20',200,1),(3,1,2,'2022-01-01',500,1),(4,1,3,'2021-05-18',100,1),(5,1,4,'2021-05-31 23:59:59',300,1),(6,2,5,'2021-05-31',3000,1),(7,1,6,'2021-05-17 23:59:59',9999,1),(8,2,7,'2021-06-01',99999,1)])
conn.executemany('INSERT INTO dbo.order_line VALUES (?,?,?,?,?,?,?,?,?)',[(i,'2021-05-20',1,i,100,100,70,1,i*100) for i in range(1,13)]+[(101,'2020-06-01',1,1,1,1,1,1,1),(102,'2020-06-30 23:59:59',1,2,1,1,1,1,1),(103,'2020-07-01',2,3,1,1,1,1,1)])
conn.executemany('INSERT INTO dbo.lost VALUES (?,?,?,?,?,?)', [('2021-05-20',1,i,146 if i%2 else 999,1,13-i if i<13 else 7) for i in range(1,14)])
text=(ROOT/'sql/solution.sql').read_text(encoding='utf8')
results={}
for i,block in enumerate(re.split(r'^GO\s*$',text,flags=re.M)[:7],1):
 parsed=sqlglot.parse(block,read='tsql')
 query=parsed[-1]
 def change(node):
  if isinstance(node,exp.Collate):return node.this.copy()
  return node
 query=query.transform(change)
 sql=query.sql(dialect='duckdb').replace('$today',"DATE '2021-06-01'")
 if i==1:sql=sql.replace(' LIKE ', ' ILIKE ')
 sql=re.sub(r"'(\d{4})(\d{2})(\d{2})'",r"'\1-\2-\3'",sql)
 result=conn.execute(sql).fetchall()
 results[str(i)]={'parsed_tsql':True,'transpiled_execution':'passed','result_rows':len(result)}
 if i==1:assert len(result)==1 and result[0][0]=='САМОКАТ'
 if i==2:assert result==[('Тест',51)]
 if i==3:
  row=next(r for r in result if r[0]=='Москва');assert row[1]==2 and float(row[2])==1
 if i==4:
  jan=[r for r in result if str(r[1])=='2021-01-01'];company=next(r for r in jan if r[0]=='Компания');assert company[2:]==(2,1) and sum(r[3] for r in jan if r[0]!='Компания')==2
 if i==5:assert len(result)==1 and result[0][0]=='Б' and abs(float(result[0][2])-3000)<1e-8 and abs(float(result[0][3])-3400/3)<1e-8
 if i==6:
  a=next(r for r in result if r[1]=='A');b=next(r for r in result if r[1]=='B');assert abs(float(a[2])-1)<1e-8 and b[2] is None and abs(float(b[3])-700/85)<1e-8
 if i==7:
  assert len(result)==13
  first=next(r for r in result if r[1]=='Товар 12');assert first[3]==1 and float(first[2])==600
  assert any(r[1]=='САМОКАТ' and r[5]==1 for r in result)
report={'engine':'DuckDB synthetic fixtures after sqlglot T-SQL transpilation','native_sql_server_executed':False,'checks':results,'edge_cases':['case insensitive Cyrillic','inclusive shelf life 7','open/close date boundary','zero-sales warehouse in denominator','month end timestamp','company distinct users across cities','weighted city check','14-day cutoff','all loss articles','group with zero sales','independent top-10 union and common Moscow denominator']}
(ROOT/'output/sql_verification.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
print('Seven T-SQL blocks parsed and seven transpiled queries executed on synthetic fixtures')

