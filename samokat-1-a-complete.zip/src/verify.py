from pathlib import Path
from datetime import datetime,timedelta
from math import isclose
from zipfile import ZipFile
from lxml import etree as E
import json
from openpyxl import load_workbook
ROOT=Path(__file__).resolve().parents[1]
file=ROOT/'output/Самокат_1_A_решение.xlsx'
w=load_workbook(file,data_only=True)
wf=load_workbook(file,data_only=False)
d=json.loads((ROOT/'qa/data.json').read_text(encoding='utf8'))
s=json.loads((ROOT/'output/summary.json').read_text(encoding='utf8'))
checks=[]
def ok(name):checks.append(name)
def close(a,b):assert isclose(float(a),float(b),abs_tol=0.00001,rel_tol=1e-11),(a,b)
for i,r in enumerate(d['rows'],2):
 assert w['Данные'].cell(i,1).value==datetime(1899,12,30)+timedelta(days=r[0])
 assert w['Данные'].cell(i,2).value==r[1]
 for j in range(2,9):close(w['Данные'].cell(i,j+1).value,r[j])
 assert w['Данные'].cell(i,10).value==datetime(1899,12,30)+timedelta(days=r[9])
 assert w['Данные'].cell(i,12).value==r[11]
ok('All 504 joined rows, 9 source columns and ISO week values reconciled to original input')
for i in range(5,14):close(w['Проверки'].cell(i,4).value,0)
ok('All nine workbook reconciliations passed')
for i,row in enumerate(s['weekly'],5):
 for col,key in [(4,'sales'),(5,'cost'),(6,'loss'),(7,'markup'),(8,'yield_rate')]:close(w['Динамика'].cell(i,col).value,row[key])
ok('Six weekly totals and weighted ratios matched independent Python aggregates')
for i,row in enumerate(s['top_share'],34):
 assert w['Итоги'].cell(i,2).value==row['territory'];close(w['Итоги'].cell(i,3).value,row['share'])
for i,row in enumerate(s['top_per_warehouse'],41):
 assert w['Итоги'].cell(i,2).value==row['territory'];close(w['Итоги'].cell(i,3).value,row['per_warehouse'])
ok('Both top-3 tables matched independent rankings')
for i,row in enumerate(s['last_week']):
 candidates=[r for r in w['Итоги'].iter_rows(min_row=12,max_row=29,values_only=True) if r[0]==row['territory']]
 assert len(candidates)==1
 v=candidates[0]
 for col,key in [(1,'sales'),(2,'share'),(3,'warehouse_days'),(4,'avg_warehouses'),(5,'per_warehouse'),(6,'markup'),(7,'yield_rate')]:close(v[col],row[key])
ok('All 18 territory rows matched independent results')
for c in range(8):
 for i,v in enumerate(d['charts'][c]['values'],5):close(w['Месячные показатели'].cell(i,c+2).value,v)
ok('All 104 cached monthly chart values preserved')
formula_count=0
for sh in wf:
 for row in sh:
  for cell in row:
   if cell.data_type=='f':formula_count+=1
for sh in w:
 for row in sh:
  for cell in row:assert cell.data_type!='e',(sh.title,cell.coordinate,cell.value)
assert formula_count>0
ok('Formula cells retained and saved calculated values contain no Excel errors')
assert len(wf['Динамика']._charts)==2
for chart in wf['Динамика']._charts:
 assert len(chart.ser)==1
 assert chart.ser[0].val.numRef.f
ok('Two native charts retain references to formula cells')
piv=wf['Сводная']._pivots
assert len(piv)==1 and len(piv[0].cache.records.r)==504
assert piv[0].cache.cacheSource.worksheetSource.ref=='A1:N505'
assert len(piv[0].rowFields)==2 and len(piv[0].dataFields)==6
last=max(r[0].row for r in w['Сводная'] if r[0].value is not None)
close(w['Сводная'].cell(last,3).value,sum(r[3] for r in d['rows']))
ok('Native pivot, 504 cache records, row/data fields, source range and grand total verified')
with ZipFile(file) as z:
 ns={'s':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
 for name in z.namelist():
  if name.startswith('xl/worksheets/sheet') and name.endswith('.xml'):
   root=E.fromstring(z.read(name));rows=root.xpath('//s:sheetData/s:row/@r',namespaces=ns)
   assert len(rows)==len(set(rows)) and list(map(int,rows))==sorted(map(int,rows))
ok('Worksheet row IDs are unique and ordered after OOXML pivot supplementation')
sql=json.loads((ROOT/'output/sql_verification.json').read_text(encoding='utf8'))
assert len(sql['checks'])==7
ok('Seven T-SQL blocks parsed and transpiled synthetic queries passed')
behavior=json.loads((ROOT/'qa/behavior.json').read_text(encoding='utf8'))
assert len(behavior)==2
checks.extend(behavior)
report={'status':'passed','checks':checks,'formula_count':formula_count,'native_sql_server_executed':False,'desktop_excel_refresh_tested':False,'numeric_tolerance':1e-5,'sql_verification':'sql_verification.json'}
(ROOT/'output/verification.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps(report,ensure_ascii=False,indent=2))
